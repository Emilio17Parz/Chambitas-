import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { db } from "../config/db.js";
import { uploadINE } from "../middleware/upload.js";

const router = express.Router();

// Ruta de prueba
router.get("/", (req, res) => {
  res.send("Ruta AUTH funcionando");
});

// Registro completo con archivo
router.post("/register", (req, res) => {
  uploadINE(req, res, async (err) => {

    if (err) {
      return res
        .status(400)
        .json({ message: "Error al subir archivo", error: err.message });
    }

    try {
      const {
        nombre,
        apellidos,
        correo,
        contraseña,
        domicilio,
        oficio,
        tipo_usuario,
        fecha_nacimiento
      } = req.body;

      if (!nombre || !correo || !contraseña || !tipo_usuario) {
        return res.status(400).json({ message: "Campos obligatorios incompletos" });
      }

      const hashedPassword = await bcrypt.hash(contraseña, 10);

      const documento_ine = req.file ? req.file.filename : null;

      const sql = `
        INSERT INTO usuarios
        (nombre, apellidos, correo, contraseña, tipo_usuario,
         fecha_nacimiento, domicilio, oficio, documento_ine)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      db.query(
        sql,
        [
          nombre,
          apellidos || null,
          correo,
          hashedPassword,
          tipo_usuario,
          fecha_nacimiento || null,
          domicilio || null,
          oficio || null,
          documento_ine
        ],
        (error, results) => {
          if (error) {
            console.error(error);
            return res.status(500).json({ message: "Error al registrar usuario" });
          }

          res.json({ message: "Usuario registrado correctamente" });
        }
      );

    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Error interno" });
    }
  });
});

// Login
router.post("/login", async (req, res) => {
  try {
    const { correo, contraseña } = req.body;

    const [rows] = await db.query(
      "SELECT * FROM usuarios WHERE correo = ?",
      [correo]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const user = rows[0];

    const valid = await bcrypt.compare(contraseña, user.contraseña);
    if (!valid) {
      return res.status(401).json({ error: "Contraseña incorrecta" });
    }

    const token = jwt.sign(
      { id: user.id, tipo: user.tipo_usuario },
      process.env.JWT_SECRET,
      { expiresIn: "3h" }
    );

    res.json({
      token,
      tipo: user.tipo_usuario,
      nombre: user.nombre
    });

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error del servidor" });
  }
});

export default router;
