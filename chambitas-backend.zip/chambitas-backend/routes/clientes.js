import express from "express";
import { db } from "../config/db.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// Obtener todos los clientes del trabajador logueado
router.get("/", verifyToken, async (req, res) => {
  try {
    const userId = req.user.id;

    const [rows] = await db.query(
      "SELECT * FROM clientes WHERE trabajador_id = ? ORDER BY fecha_registro DESC",
      [userId]
    );

    res.json(rows);

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error al obtener clientes" });
  }
});

// Crear cliente
router.post("/", verifyToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const { nombre, telefono, direccion, notas } = req.body;

    await db.query(
      `INSERT INTO clientes 
      (trabajador_id, nombre, telefono, direccion, notas)
      VALUES (?, ?, ?, ?, ?)`,
      [userId, nombre, telefono, direccion, notas]
    );

    res.json({ message: "Cliente agregado" });

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error al agregar cliente" });
  }
});

// Editar cliente
router.put("/:id", verifyToken, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const { nombre, telefono, direccion, notas } = req.body;

    await db.query(
      `UPDATE clientes 
       SET nombre=?, telefono=?, direccion=?, notas=?
       WHERE id=? AND trabajador_id=?`,
      [nombre, telefono, direccion, notas, id, userId]
    );

    res.json({ message: "Cliente actualizado" });

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error al editar cliente" });
  }
});

// Eliminar cliente
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    await db.query(
      "DELETE FROM clientes WHERE id=? AND trabajador_id=?",
      [id, userId]
    );

    res.json({ message: "Cliente eliminado" });

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error al eliminar cliente" });
  }
});

export default router;
