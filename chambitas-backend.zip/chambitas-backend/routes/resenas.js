import express from "express";
import { db } from "../config/db.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// Ruta de prueba
router.get("/", (req, res) => {
  res.send("Ruta RESEÑAS funcionando (sin ñ 😅)");
});

// Crear reseña
router.post("/crear", verifyToken, async (req, res) => {
  try {
    const { id_trabajador, comentario, calificacion } = req.body;

    await db.query(
      "INSERT INTO reseñas (id_cliente, id_trabajador, comentario, calificacion) VALUES (?, ?, ?, ?)",
      [req.user.id, id_trabajador, comentario, calificacion]
    );

    res.json({ message: "Reseña creada con éxito" });

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error al crear la reseña" });
  }
});

// Obtener reseñas de un trabajador
router.get("/:id_trabajador", async (req, res) => {
  try {
    const { id_trabajador } = req.params;

    const [rows] = await db.query(
      "SELECT * FROM reseñas WHERE id_trabajador = ?",
      [id_trabajador]
    );

    res.json(rows);

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error obteniendo reseñas" });
  }
});

export default router;
