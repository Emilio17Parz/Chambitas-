import express from "express";
import { db } from "../config/db.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// Obtener perfil del usuario logeado
router.get("/me", verifyToken, async (req, res) => {
  try {
    const userId = req.user.id;

    const [rows] = await db.query(
      "SELECT id, nombre, correo, tipo_usuario, fecha_registro FROM usuarios WHERE id = ?",
      [userId]
    );

    if (rows.length === 0)
      return res.status(404).json({ error: "Usuario no encontrado" });

    const user = rows[0];

    // Si es trabajador, obtener datos extra
    if (user.tipo_usuario === "trabajador") {
      const [extra] = await db.query(
        `SELECT categoria_id, descripcion, experiencia, telefono, zona 
         FROM trabajadores WHERE id = ?`,
        [userId]
      );

      user.detalles = extra.length ? extra[0] : null;
    }

    res.json(user);

  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Error al obtener perfil" });
  }
});
// OBTENER LISTA DE TRABAJADORES
router.get("/trabajadores", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT u.id, u.nombre, t.descripcion, t.experiencia, t.telefono, t.zona,
             c.nombre AS categoria
      FROM usuarios u
      JOIN trabajadores t ON u.id = t.id
      JOIN categorias c ON c.id = t.categoria_id
    `);

    res.json(rows);
    
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al obtener trabajadores" });
  }
});

export default router;
