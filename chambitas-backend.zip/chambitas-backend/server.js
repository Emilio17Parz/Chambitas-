import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { db } from "./config/db.js";

import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/users.js";
import citasRoutes from "./routes/citas.js";
import resenasRoutes from "./routes/resenas.js";

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/citas", citasRoutes);
app.use("/api/resenas", resenasRoutes);

app.get("/", (req, res) => {
  res.send("API CHAMBITAS funcionando 🚀");
});

app.listen(process.env.PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${process.env.PORT}`);
});
